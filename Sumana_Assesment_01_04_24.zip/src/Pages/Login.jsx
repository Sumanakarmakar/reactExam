import axios from 'axios'
import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify';

const Login = () => {
    const initialValue = {
        email: "",
        password: ""
    }

    const [userLog, setUserLog] = useState(initialValue)
    const navigate=useNavigate()

    const changeValue = (e) => {
        const { name, value } = e.target
        setUserLog({ ...userLog, [name]: value })
        console.log(userLog);
    }

    const onSubmits = (e) => {
        e.preventDefault()
        console.log("jhhkb");
        const url = 'https://restapinodejs.onrender.com/api/login'
        let addLogInData = axios.post(url, userLog)
            .then((response) => {
                console.log(response);
                if (response) {
                    console.log(response?.data);
                    toast.success(response?.data?.message)
                    navigate('/blog')
                }
            })
            .catch((error) => {
                console.log(error);
            })
    }
    return (
        <>


            <div className='about'>
                <form action="" className='form_container mt-5 mx-auto' onSubmit={onSubmits}>
                    <div className='form_header'>
                        <h1>Log In</h1>
                    </div>

                    <div>
                        <label htmlFor="">Email</label>
                        <input type="email" className='form-control' placeholder='Enter your registered email' name='email' onChange={changeValue} value={userLog.email} />
                    </div>

                    <div>
                        <label htmlFor="">Password</label>
                        <input type="password" className='form-control' placeholder='Enter your password' name='password' onChange={changeValue} value={userLog.password} />
                    </div>

                    <div>
                        <button className='form_btn'>Log In</button>
                    </div>

                </form>


                <div>
                    <p>New User!<u><Link to='/register_page'>Go to Register page</Link></u></p>
                </div>
            </div>


        </>
    )
}

export default Login